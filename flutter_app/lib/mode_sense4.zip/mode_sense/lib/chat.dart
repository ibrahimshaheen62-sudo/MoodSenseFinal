import 'dart:convert';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

// --- Imports for Navigation (based on your file structure) ---
import 'HistoryPage.dart';
import 'MyAccountPage.dart';
// import 'SettingsPage.dart'; // You can import this for 'Light mode' logic
import 'UpdatesFAQPage.dart';
import 'Sign_in.dart'; // Import your sign-in page for logout navigation
// ----------------------------------------------------

// --- Defined AppColors to resolve compile errors ---
// Based on the previous image, AppColors.lightGreen is assumed to be the button green.
class AppColors {
  static const Color black = Colors.black;
  static const Color lightGreen = Color(0xFF4CAF50); // Bright green
}
// ----------------------------------------------------

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final TextEditingController _controller = TextEditingController();
  final List<Map<String, String>> _messages = [];
  bool _isLoading = false;

  // API URL
  // final String apiUrl = "http://10.0.2.2:8000/chat"; // Emulator
  //final String apiUrl = "http://192.168.1.127:8000/chat"; // Real device

  final String apiUrl = "http://127.0.0.1:8000/chat";


  Future<void> sendMessage(String userMessage) async {
    final uid = FirebaseAuth.instance.currentUser?.uid ?? "unknown";
    const conversationId = "conv1"; // could generate dynamically later

    setState(() {
      _messages.add({"role": "user ", "content": userMessage});
      _isLoading = true;
    });

    try {
      // Prepare full chat history
      List<Map<String, String>> messagesForApi = _messages.map((m) {
        return {"role": m["role"]!, "content": m["content"]!};
      }).toList();

      final response = await http.post(
        Uri.parse(apiUrl),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({
          "uid": uid,
          "conversation_id": conversationId,
          "messages": messagesForApi,
        }),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final botReply = data["reply"];

        // Save bot message to Firestore
        await FirebaseFirestore.instance
            .collection("users")
            .doc(uid)
            .collection("conversations")
            .doc(conversationId)
            .collection("messages")
            .add({
          "role": "bot",
          "content": botReply,
          "timestamp": DateTime.now(),
        });

        setState(() {
          _messages.add({"role": "bot", "content": botReply});
        });
      } else {
        setState(() {
          _messages.add({
            "role": "bot",
            "content": "Error: ${response.statusCode}"
          });
        });
      }
    } catch (e) {
      setState(() {
        _messages.add({"role": "bot", "content": "Connection issue: $e"});
      });
    }

    setState(() {
      _isLoading = false;
    });
  }

  // --- Helper function for Sign Out ---
  void _handleSignOut(BuildContext context) async {
    await FirebaseAuth.instance.signOut();
    // Navigate to Sign_in screen and remove all previous routes
    if (mounted) {
      Navigator.of(context).pushAndRemoveUntil(
        MaterialPageRoute(builder: (context) => const SignIn()), // Assumes your class is named SignIn
            (Route<dynamic> route) => false,
      );
    }
  }

  // --- Helper function for New Chat ---
  void _startNewChat() {
    Navigator.pop(context); // Close drawer
    setState(() {
      _messages.clear(); // Clear the local chat messages
      // TODO: You might want to update conversationId here
    });
  }

  // --- Helper function for Clearing Conversations ---
  void _clearConversations() {
    Navigator.pop(context);
    // TODO: Add logic to clear backend history (Firestore)
    // For now, just clears local state
    setState(() {
      _messages.clear();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        iconTheme: const IconThemeData(color: Colors.black), // Make drawer icon black
        title: Text.rich(
          TextSpan(
            children: [
              const TextSpan(
                text: 'MOOD ',
                style: TextStyle(
                  fontSize: 26,
                  fontWeight: FontWeight.w400,
                  color: AppColors.black,
                  letterSpacing: 1.2,
                ),
              ),
              TextSpan(
                text: 'SENSE',
                style: TextStyle(
                  fontSize: 26,
                  fontWeight: FontWeight.w400,
                  color: AppColors.lightGreen,
                  letterSpacing: 1.2,
                ),
              ),
            ],
          ),
        ),
        centerTitle: true,
        backgroundColor: Colors.white,
        surfaceTintColor: Colors.white,
      ),

      // --- NEW DRAWER WIDGET ---
      drawer: Drawer(
        backgroundColor: Colors.white,
        child: Column(
          children: [
            // --- Top Section ---
            Column(
              children: [
                // Padding for status bar
                SizedBox(height: MediaQuery.of(context).padding.top + 10),

                // "New chat" button
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 10.0),
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      // This light green matches the image
                      backgroundColor: const Color(0xFFE8F5E9),
                      foregroundColor: Colors.black, // Black text/icon
                      elevation: 0,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8.0),
                      ),
                      minimumSize: const Size.fromHeight(48),
                    ),
                    onPressed: _startNewChat,
                    child: const Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.add, size: 20),
                        SizedBox(width: 8),
                        Text("New chat", style: TextStyle(fontSize: 16)),
                      ],
                    ),
                  ),
                ),

                // "History of conversations" tile
                ListTile(
                  leading: const Icon(Icons.history, color: Colors.black54),
                  title: const Text("History of conversations"),
                  onTap: () {
                    Navigator.pop(context);
                    Navigator.push(context, MaterialPageRoute(builder: (context) => const Historypage()));
                  },
                ),

                // "New chat" tile
                ListTile(
                  leading: const Icon(Icons.chat_bubble_outline, color: Colors.black54),
                  title: const Text("New chat"),
                  onTap: _startNewChat,
                ),

             ListTile(
                title:Text( "History"),

               onTap: () {
                 Navigator.pushReplacement(
                   context,
                   MaterialPageRoute(
                       builder: (context) => const Historypage()),
                 );
               },



             ),
              ],
            ),

            // --- Spacer ---
            const Expanded(child: SizedBox()),

            // --- Bottom Section ---
            Column(
              children: [
                const Divider(height: 1, indent: 16, endIndent: 16),

                // "Clear conversations" tile
                ListTile(
                  leading: const Icon(Icons.delete_outline, color: Colors.black54),
                  title: const Text("Clear conversations"),
                  onTap: _clearConversations,
                ),

                // "Light mode" tile
                ListTile(
                  leading: const Icon(Icons.light_mode_outlined, color: Colors.black54),
                  title: const Text("Light mode"),
                  onTap: () {
                    Navigator.pop(context);
                    // TODO: Implement light/dark mode toggle


                  },
                ),

                // "My account" tile
                ListTile(
                  leading: const Icon(Icons.person_outline, color: Colors.black54),
                  title: const Text("My account"),
                  onTap: () {
                    Navigator.pop(context);
                    Navigator.push(context, MaterialPageRoute(builder: (context) => const MyAccountPage()));
                  },
                ),

                // "Updates & FAQ" tile
                ListTile(
                  leading: const Icon(Icons.help_outline, color: Colors.black54),
                  title: const Text("Updates & FAQ"),
                  onTap: () {
                    Navigator.pop(context);
                    Navigator.push(context, MaterialPageRoute(builder: (context) => const UpdatesFAQPage()));
                  },
                ),

                // "Log out" tile
                ListTile(
                  leading: const Icon(Icons.logout, color: Colors.black54),
                  title: const Text("Log out"),
                  onTap: () => _handleSignOut(context),
                ),

                // Padding for bottom safe area
                SizedBox(height: MediaQuery.of(context).padding.bottom + 10),
              ],
            ),
          ],
        ),
      ),
      // --- END OF DRAWER ---

      body: Column(
        children: [


          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.all(12),
              itemCount: _messages.length,
              itemBuilder: (context, index) {
                final msg = _messages[index];
                final isUser = msg["role"] == "user";
                return Align(
                  alignment:
                  isUser ? Alignment.centerRight : Alignment.centerLeft,
                  child: Container(
                    margin: const EdgeInsets.symmetric(vertical: 4),
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: isUser ? Colors.teal[100] : Colors.lightGreen[300],
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text(msg["content"] ?? ""),
                  ),
                );
              },
            ),
          ),


          if (_isLoading) const LinearProgressIndicator(color: AppColors.lightGreen),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _controller,
                    enabled: !_isLoading,
                    decoration: InputDecoration(
                      hintText: "اكتب رسالتك...",
                      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(25),
                        borderSide: BorderSide(color: Colors.grey.shade300),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(25),
                        borderSide: const BorderSide(color: AppColors.lightGreen),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                IconButton(
                  icon: const Icon(Icons.send, color: AppColors.lightGreen),
                  onPressed: () {
                    if (_controller.text.isNotEmpty) {
                      sendMessage(_controller.text);
                      _controller.clear();
                    }
                  },
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

