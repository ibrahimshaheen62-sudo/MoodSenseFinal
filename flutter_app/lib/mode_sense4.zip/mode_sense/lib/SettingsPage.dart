import 'dart:convert';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

// --- Imports for Navigation (based on your file structure) ---
import 'HistoryPage.dart';
import 'MyAccountPage.dart';
// import 'SettingsPage.dart'; // You can import this for 'Light mode' logic
import 'UpdatesFAQPage.dart';
import 'Sign_in.dart';




class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});

  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
    );

  }
}