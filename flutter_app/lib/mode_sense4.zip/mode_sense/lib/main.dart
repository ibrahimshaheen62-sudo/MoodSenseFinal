import 'package:flutter/material.dart';
import 'package:flutter_application_1/HistoryPage.dart';
import 'package:flutter_application_1/MyAccountPage.dart';
import 'package:flutter_application_1/SettingsPage.dart';
import 'package:flutter_application_1/Sign_in.dart';
import 'package:flutter_application_1/UpdatesFAQPage.dart';
import 'package:flutter_application_1/chat.dart';
import 'package:flutter_application_1/sign_up.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'firebase_options.dart';
import 'package:provider/provider.dart'; // Make sure provider is added to pubspec.yaml
import 'chat.dart';



// If you have a custom AuthProvider, import it here
// import 'package:flutter_application_1/providers/auth_provider.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);


  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      initialRoute: '/',
      routes: {
        '/': (context) => SignUpPage(),
        '/SignIn': (context) => SignIn(),
        '/chatpage': (context) => ChatScreen(),
        '/HistoryPage': (context) => Historypage(),
        '/MyAccountPage': (context) => MyAccountPage(),
        '/UpdatesFAQPage': (context) => UpdatesFAQPage(),
        '/Settingspage': (context) => SettingsPage(),





      },
    );
  }
}
