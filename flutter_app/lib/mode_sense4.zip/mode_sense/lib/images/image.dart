class ImagesAssets {
  static const String mode = 'assets/images/png/ModeSense.png';
  static const String google = 'assets/images/png/google.png';
}
